# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.modules', 'gendiff.scripts', 'gendiff.tests']

package_data = \
{'': ['*'], 'gendiff.tests': ['fixtures/*']}

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Compares two configuration files and shows a difference.',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/violetomo/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/violetomo/python-project-50/actions)\n### gendiff with .json files asciinema example\nhttps://asciinema.org/a/5B0TNAPO5tSEvqVwhRcM9Gf3M\n',
    'author': 'violetomo',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
