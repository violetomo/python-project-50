# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.modules', 'gendiff.scripts', 'gendiff.tests']

package_data = \
{'': ['*'], 'gendiff.tests': ['fixtures/*']}

install_requires = \
['PyYAML>=6.0,<7.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Compares two configuration files and shows a difference.',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/violetomo/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/violetomo/python-project-50/actions)\n### Build-and-test\n[![Actions Status](https://github.com/violetomo/python-project-50/actions/workflows/main.yml/badge.svg)](https://github.com/violetomo/python-project-50/actions)\n### Codeclimate\n[![Test Coverage](https://api.codeclimate.com/v1/badges/b1935eb0397277e7e303/test_coverage)](https://codeclimate.com/github/violetomo/python-project-50/test_coverage)\n### gendiff with .json files asciinema example\nhttps://asciinema.org/a/5B0TNAPO5tSEvqVwhRcM9Gf3M\n',
    'author': 'violetomo',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
