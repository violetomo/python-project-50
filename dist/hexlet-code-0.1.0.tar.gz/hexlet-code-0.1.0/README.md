### Hexlet tests and linter status:
[![Actions Status](https://github.com/violetomo/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/violetomo/python-project-50/actions)
### gendiff with .json files asciinema example
https://asciinema.org/a/5B0TNAPO5tSEvqVwhRcM9Gf3M
