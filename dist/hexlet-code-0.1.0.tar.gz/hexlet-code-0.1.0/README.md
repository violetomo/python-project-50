### Hexlet tests and linter status:
[![Actions Status](https://github.com/violetomo/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/violetomo/python-project-50/actions)
### Build-and-test
[![Actions Status](https://github.com/violetomo/python-project-50/actions/workflows/main.yml/badge.svg)](https://github.com/violetomo/python-project-50/actions)
### Codeclimate
[![Test Coverage](https://api.codeclimate.com/v1/badges/b1935eb0397277e7e303/test_coverage)](https://codeclimate.com/github/violetomo/python-project-50/test_coverage)
### gendiff with .json files asciinema example
https://asciinema.org/a/5B0TNAPO5tSEvqVwhRcM9Gf3M
